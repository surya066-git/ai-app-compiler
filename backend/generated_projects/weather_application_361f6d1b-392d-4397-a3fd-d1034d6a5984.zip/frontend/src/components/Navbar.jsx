<nav className="bg-gray-800 p-4">
  <div className="container mx-auto flex justify-between items-center">
    <span className="text-white text-lg font-semibold">My App Title</span>
    <button
      onClick={() => console.log('Logout clicked')}
      className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
    >
      Logout
    </button>
  </div>
</nav>