import React from 'react';
import { Link } from 'react-router-dom';
import { CloudSun } from 'lucide-react'; // Using CloudSun as a suitable icon for weather

const Sidebar = () => {
  return (
    <div className="flex flex-col h-screen w-64 bg-gray-800 text-white shadow-lg fixed top-0 left-0">
      <div className="flex items-center justify-center h-16 border-b border-gray-700">
        <h1 className="text-xl font-semibold">My App</h1>
      </div>
      <nav className="flex-1 px-2 py-4 space-y-2">
        <Link 
          to="/weather" 
          className="flex items-center space-x-3 p-3 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
        >
          <CloudSun className="w-5 h-5" />
          <span>Weather Display Page</span>
        </Link>
      </nav>
    </div>
  );
};

export default Sidebar;