import React from 'react';
export default function Weatherdisplaypage() { return <div className='p-6'><h1 className='text-2xl font-bold'>Weatherdisplaypage</h1></div>; }