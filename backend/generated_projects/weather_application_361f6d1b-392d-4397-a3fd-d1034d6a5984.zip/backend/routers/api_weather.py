
from fastapi import APIRouter
router = APIRouter()
@router.get("/")
def handle_api_weather():
    return {"message": "Fetches current weather, hourly forecast, and daily forecast data for a given city."}
