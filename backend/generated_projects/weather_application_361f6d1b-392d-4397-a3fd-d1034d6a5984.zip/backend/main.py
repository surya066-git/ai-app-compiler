
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database import engine, Base
import models
import auth
from routers import api_weather


# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Weather Application")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(api_weather.router, prefix='/api_weather', tags=['api_weather'])


@app.get("/")
def health_check():
    return {"status": "ok", "app": "Weather Application"}
